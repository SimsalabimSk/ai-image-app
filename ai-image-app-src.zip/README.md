# AI Image App (MVP v0.1) — U1 thin slice

This repo scaffolds an intent-first image generation MVP:
- FastAPI API (`apps/api`)
- Celery worker (`apps/worker`)
- Shared code (`packages/common`)
- Infra (`infra/docker-compose.yml`)
- OpenAPI source-of-truth (`openapi/openapi.v0.1.2.yaml`)

## Quickstart (local)
1) Install deps (optional for local dev outside Docker):
```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .[dev]
```

2) Start services:
```bash
docker compose -f infra/docker-compose.yml up --build
```

API: http://localhost:8000/docs

## Notes
- DB migrations (Alembic) will be added in T04.
- Mock model adapter + end-to-end run will be added in later tickets.

## T07
- Implemented `POST /intent` (IM-1 minimal) storing intent_spec_json.

## T08
- Added orchestrator stub to build deterministic OrchestrationPlan for MVP U1.

## T09
- Implemented `POST /run` (create run, store orchestration_plan_json, emit RUN_CREATED/RUN_QUEUED/ORCHESTRATION_DECIDED, enqueue Celery `execute_run`).

## T10
- Added Celery task registry with `execute_run` stub (real implementation in T13).

## T11
- Added mock deterministic PNG generator adapter (Pillow) for worker.

## T12
- Added S3-compatible MinIO storage client + temp storage paths + sha256.

## T13
- Implemented worker execute_run end-to-end: run status updates, mock PNG gen, MinIO store, assets + events + latest_temp_asset_id.

## T14
- Added read endpoints: GET /run/{run_id}, /run/{run_id}/events, /run/{run_id}/explain.

## T15
- Added GET /asset/{asset_id} with MinIO presigned redirect and temp TTL expiry -> 410.

## T16
- Added end-to-end smoke script: `python scripts/smoke_e2e.py` (requires docker compose up).

## T17
- Added Makefile for one-command dev: `make dev` (compose up + migrate + seed + smoke).

## T18
- Added GitHub Actions CI smoke job: docker compose up + migrate + seed + smoke_e2e.

## T19
- Contract freeze: OpenAPI v0.1.2 + DB schema v0.1.0 locked via contracts/lock.m0.1.json and verified in CI.

## T20
- Release metadata: VERSION files + CHANGELOG + publish checklist (MVP v0.1.0).

## T21
- Stability audit: added static_audit (no-docker) + patch log P-APP-001.
